<?php exec('sudo python mv_fw.py'); ?>

<html>
<head>
	<title>Let's Start RPC</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
	<div class="switch">
		<div class="body">
			<div class="volume"></div>
			<div class="screen">
				<div class="logo">
					<div class="icon">
						<div class="icon-part left">
						</div>
						<div class="icon-part right"></div>
					</div>
					<h1><span>Nintendo</span>Switch</h1>
				</div>
			</div>
		</div>

		<div class="joy-con left">
			<div class="button-group">
				<form method="post" action="move_forward.php">
					<div class="button arrow up">
						<input type="submit" name="btn_up" value="move_forward">
					</div>
				</form>
				<div class="button arrow right">
				</div>
				<div class="button arrow down">
				</div>
				<div class="button arrow left">
				</div>
			</div>

			<div class="stick"></div>
			<form method="post" action="move_right.php">
				<input type="submit" name="btn_rt" value="right">
			</form>
			<div class="select"></div>
			<div class="capture"></div>
			<div class="shoulder l"></div>
		</div>
		<div class="joy-con right">
			<div class="button-group">
				<form method="post" action="move_backward.php">
					<div class="button letter" data-letter="X">
						<input type="submit" name="btn_down" value="move_backward">
					</div>
				</form>
				<div class="button letter" data-letter="A"></div>
				<div class="button letter" data-letter="B"></div>
				<div class="button letter" data-letter="Y"></div>
			</div>

			<form method="post" action="move_left.php">
				<div class="button letter" data-letter="X">
					<input type="submit" name="btn_lt" value="left">
				</div>
			</form>

			<div class="stick"></div>
			<div class="start"></div>
			<div class="home">
				<form method="post" action="move_stop.php">
					<div class="button letter" data-letter="X">
						<input type="submit" name="btn_st" value="stop">
					</div>
				</form>
			</div>
			<div class="shoulder r"></div>
		</div>
	</div>
</body>
</html>
